package com.taxxib.enterprise.ui.activity.invite;

import com.taxxib.enterprise.user.R;
import com.taxxib.enterprise.base.BaseActivity;

public class InviteActivity extends BaseActivity {

    @Override
    public int getLayoutId() {
        return R.layout.activity_invite;
    }

    @Override
    public void initView() {

    }
}
