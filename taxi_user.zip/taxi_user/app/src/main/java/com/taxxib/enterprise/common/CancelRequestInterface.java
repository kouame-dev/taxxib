package com.taxxib.enterprise.common;

/**
 * Created by santhosh@appoets.com on 03-07-2018.
 */
public interface CancelRequestInterface {
    public void cancelRequestMethod();

}
