package com.taxxib.enterprise.common;

/**
 * Created by santhosh@appoets.com on 13-08-2018.
 */
public class InfoWindowData{
    private String address;
    private String arrival_time;

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getArrival_time() {
        return arrival_time;
    }

    public void setArrival_time(String arrival_time) {
        this.arrival_time = arrival_time;
    }

    public String getDistance() {
        return distance;
    }

    public void setDistance(String distance) {
        this.distance = distance;
    }

    private String distance;

}
