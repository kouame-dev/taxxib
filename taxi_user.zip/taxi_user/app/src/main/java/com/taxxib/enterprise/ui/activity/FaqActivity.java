package com.taxxib.enterprise.ui.activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.taxxib.enterprise.user.R;

public class FaqActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_faq);
    }
}
